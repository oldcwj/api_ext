=== wpappxyz ===
Contributors: wpapp.xyz
Tags: android, app, wpapp.xyz
Requires at least: 4.3
Tested up to: 4.4.1
Stable tag: 3.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

This plug-in is a REST-API plug-in expansion.
When you want to get the time Posts, featured_image field not return a detailed picture address, if you want to address the need for a detailed request to do it again. So amended as direct access to image addresses.
While adding the offset field for paging get posts.

== Installation ==

= WordPress Admin Method =
1. Go to you administration area in WordPress `Plugins > Add`
2. Look for `wpappxyz` (use search form)
3. Click on Install and activate the plugin
4. Find the settings page through `Settings > wpappxyz`

= FTP Method =
1. Upload the complete `wpappxyz` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Find the settings page through `Settings > wpappxyz`

== Changelog ==

= 0.0.1 =
* Initial release.