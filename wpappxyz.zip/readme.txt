=== wpappxyz ===
Contributors: wpapp.xyz
Tags: android, app, wpapp.xyz
Requires at least: 4.3
Tested up to: 4.4.1
Stable tag: 3.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

rest json api ext
use with (WP REST API) plugin

== Installation ==

= WordPress Admin Method =
1. Go to you administration area in WordPress `Plugins > Add`
2. Look for `wpappxyz` (use search form)
3. Click on Install and activate the plugin
4. Find the settings page through `Settings > wpappxyz`

= FTP Method =
1. Upload the complete `wpappxyz` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Find the settings page through `Settings > wpappxyz`

== Changelog ==

= 0.0.1 =
* Initial release.